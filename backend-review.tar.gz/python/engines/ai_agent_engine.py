
# import os
# import json
# import httpx
# from dotenv import load_dotenv

# load_dotenv()

# KAGGLE_AI_URL = os.getenv("KAGGLE_AI_URL", "").rstrip("/")
# KAGGLE_AI_TOKEN = os.getenv("KAGGLE_AI_TOKEN", "")


# async def ask_kaggle_qwen(prompt: str, context: dict, agent: str = "log_analysis"):
#     if not KAGGLE_AI_URL:
#         raise RuntimeError("Chưa cấu hình KAGGLE_AI_URL trong .env")

#     if not KAGGLE_AI_TOKEN:
#         raise RuntimeError("Chưa cấu hình KAGGLE_AI_TOKEN trong .env")

#     # Gửi cả câu hỏi và dữ liệu Wazuh lên Kaggle
#     full_prompt = (
#         f"CÂU HỎI:\n{prompt}\n\n"
#         f"DỮ LIỆU HỆ THỐNG:\n"
#         f"{json.dumps(context, ensure_ascii=False, indent=2, default=str)}"
#     )

#     headers = {
#         "Authorization": f"Bearer {KAGGLE_AI_TOKEN}",
#         "Content-Type": "application/json"
#     }

#     payload = {
#         "prompt": full_prompt,
#         "agent": agent
#     }

#     async with httpx.AsyncClient(timeout=300) as client:
#         response = await client.post(
#             f"{KAGGLE_AI_URL}/analyze",
#             json=payload,
#             headers=headers
#         )

#         response.raise_for_status()
#         result = response.json()

#     # Trả kết quả Qwen về backend
#     return result.get("result") or result.get("response") or result.get("answer") or result



import os
import json
import httpx
from dotenv import load_dotenv

load_dotenv()

KAGGLE_AI_URL = os.getenv("KAGGLE_AI_URL", "").rstrip("/")
KAGGLE_AI_TOKEN = os.getenv("KAGGLE_AI_TOKEN", "")


async def ask_kaggle_qwen(
    prompt: str,
    context: dict,
    agent: str = "log_analysis"
):
    """
    Tạm thời kiểm tra kết nối chat Wazuh Assistant.
    Nhận bất kỳ nội dung nào và trả về thông báo xác nhận.
    Chưa gọi Kaggle hoặc Qwen.
    """

    prompt = str(prompt or "").strip()

    if not prompt:
        return "Đã nhận được tin nhắn của bạn."

    return "Đã nhận được tin nhắn của bạn."